from .base import BaseEar as BaseEar
from .stt_deepgram import Ear_deepgram as Ear_deepgram
# from .stt_vosk import Ear_vosk as Ear_vosk
from .stt_hf import Ear_hf as Ear_hf