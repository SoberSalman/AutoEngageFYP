from .base import BaseMouth as BaseMouth
from .tts_elevenlabs import Mouth_elevenlabs as Mouth_elevenlabs
from .tts_hf import Mouth_hf as Mouth_hf
from .tts_parler import Mouth_parler as Mouth_parler
from .tts_piper import Mouth_piper as Mouth_piper
# from .tts_tortoise import Mouth as Mouth_tortoise
from .tts_xtts import Mouth_xtts as Mouth_xtts
